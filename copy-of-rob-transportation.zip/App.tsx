
import React, { useState, useCallback, useEffect } from 'react';
import { BookingData, VehicleOption, BookingStep } from './types';
import { VEHICLE_OPTIONS } from './constants';
import Header from './components/Header';
import Footer from './components/Footer';
import BookingForm from './components/BookingForm';
import { generateCreativeConfirmation } from './gemini';
import BookingSummary from './components/BookingSummary';
import ConfirmationPage from './components/ConfirmationPage';
import AdminDashboard from './components/AdminDashboard';
import LoadingSpinner from './components/LoadingSpinner';
import Alert from './components/Alert'; 

const initialBookingData: Omit<BookingData, 'id' | 'created_at'> = {
  pickupLocation: '',
  dropoffLocation: '',
  dateTime: '',
  vehicleType: null,
  name: '',
  phone: '',
  email: '',
};

const App: React.FC = () => {
  const [currentStep, setCurrentStep] = useState<BookingStep>(BookingStep.FORM);
  const [bookingDetails, setBookingDetails] = useState<Omit<BookingData, 'id' | 'created_at'>>(initialBookingData);
  const [isLoading, setIsLoading] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);
  const [confirmationMessage, setConfirmationMessage] = useState<string>('');
  
  const [allBookings, setAllBookings] = useState<BookingData[]>([]);
  const [view, setView] = useState<'customer' | 'admin'>('customer');

  useEffect(() => {
    const fetchBookings = async () => {
      if (!supabase) {
        console.warn("Supabase client not initialized. Cannot fetch bookings.");
        setApiError("Database connection not configured. Please check setup.");
        return;
      }
      setIsLoading(true);
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching bookings:', error);
        setApiError(`Failed to load bookings: ${error.message}`);
      } else {
        setAllBookings(data as unknown as BookingData[]);
      }
      setIsLoading(false);
    };

    if (view === 'admin') {
      fetchBookings();
    }
  }, [view]);

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setBookingDetails(prev => ({ ...prev, [name]: value }));
  }, []);

  const handleVehicleSelect = useCallback((vehicle: VehicleOption) => {
    setBookingDetails(prev => ({ ...prev, vehicleType: vehicle.id }));
  }, []);
  
  const validateForm = (): boolean => {
    if (!bookingDetails.pickupLocation || !bookingDetails.dropoffLocation || !bookingDetails.dateTime || !bookingDetails.vehicleType || !bookingDetails.name || !bookingDetails.phone || !bookingDetails.email) {
      setApiError("Please fill in all required fields.");
      return false;
    }
    if (!bookingDetails.pickupLocation.toLowerCase().includes('seattle')) {
      setApiError("Pickup service is currently available only in the Seattle area. Please enter a valid Seattle location.");
      return false;
    }
    if (!/\S+@\S+\.\S+/.test(bookingDetails.email)) {
      setApiError("Please enter a valid email address.");
      return false;
    }
    if (!/^\+?[0-9\s-]{10,}$/.test(bookingDetails.phone)) {
        setApiError("Please enter a valid phone number.");
        return false;
    }
    setApiError(null);
    return true;
  };

  const handleProceedToSummary = () => {
    if (validateForm()) {
      setCurrentStep(BookingStep.SUMMARY);
    }
  };

  const handleConfirmBooking = async () => {
    setIsLoading(true);
    setApiError(null);

    const vehicleName = VEHICLE_OPTIONS.find(v => v.id === bookingDetails.vehicleType)?.name || 'selected vehicle';
    const passengerName = bookingDetails.name || 'Valued Customer';
    
    try {
      if (!supabase) throw new Error("Database client not available.");
      
      const { data: newBooking, error: dbError } = await supabase
        .from('bookings')
        .insert([bookingDetails])
        .select()
        .single();
      
      if (dbError) throw dbError;

      setAllBookings(prev => [newBooking as unknown as BookingData, ...prev]);

      // Now that booking is saved, trigger emails and creative message
      const confirmationPromise = generateCreativeConfirmation(vehicleName, passengerName);
      // Mock email sending
      const emailPromise = new Promise(resolve => setTimeout(() => {
        console.log("Email API call simulated for booking:", newBooking);
        resolve(true);
      }, 500));


      const [creativeMsg] = await Promise.all([
          confirmationPromise,
          emailPromise
      ]);
      
      setConfirmationMessage(creativeMsg);
      setCurrentStep(BookingStep.CONFIRMED);

    } catch (error) {
      console.error("Booking failed:", error);
      const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
      const userFriendlyError = `Booking failed: ${errorMessage}. Please try again.`;
      setApiError(userFriendlyError);
      setCurrentStep(BookingStep.SUMMARY);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditBooking = () => {
    setCurrentStep(BookingStep.FORM);
    setApiError(null);
  };

  const handleNewBooking = () => {
    setBookingDetails(initialBookingData);
    setCurrentStep(BookingStep.FORM);
    setConfirmationMessage('');
    setApiError(null);
    setView('customer');
  };
  
  const selectedVehicle = bookingDetails.vehicleType ? VEHICLE_OPTIONS.find(v => v.id === bookingDetails.vehicleType) : null;

  const renderCustomerView = () => {
    switch (currentStep) {
      case BookingStep.FORM:
        return (
          <BookingForm
            bookingDetails={bookingDetails}
            onInputChange={handleInputChange}
            onVehicleSelect={handleVehicleSelect}
            onSubmit={handleProceedToSummary}
            vehicleOptions={VEHICLE_OPTIONS}
          />
        );
      case BookingStep.SUMMARY:
        return selectedVehicle && (
          <BookingSummary
            bookingDetails={bookingDetails}
            vehicle={selectedVehicle}
            onConfirm={handleConfirmBooking}
            onEdit={handleEditBooking}
          />
        );
      case BookingStep.CONFIRMED:
         return (
          <ConfirmationPage
            bookingDetails={bookingDetails}
            vehicle={selectedVehicle}
            message={confirmationMessage}
            onNewBooking={handleNewBooking}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-brand-bg text-brand-text">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8 max-w-4xl">
        {isLoading && <LoadingSpinner />}
        {apiError && !isLoading && <Alert message={apiError} type="error" onClose={() => setApiError(null)} />}
        
        {view === 'customer' ? (
          renderCustomerView()
        ) : (
          <AdminDashboard 
            bookings={allBookings}
            onNavigateToCustomer={handleNewBooking}
            isLoading={isLoading}
          />
        )}
      </main>
      <Footer onNavigateToAdmin={() => setView('admin')} />
    </div>
  );
};

export default App;