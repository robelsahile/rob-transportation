
import { GoogleGenAI } from "@google/genai";

// Per instructions, assume process.env.API_KEY is available in the execution environment.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateCreativeConfirmation = async (vehicleName: string, passengerName: string): Promise<string> => {
  const prompt = `Generate a short, exciting, and luxurious-sounding confirmation message for a premium car service booking. The passenger's name is "${passengerName}" and they have booked a "${vehicleName}". The tone should be celebratory and reassuring. Make it sound like an unforgettable experience is about to begin. Address the passenger by their name. Keep it concise (around 2-3 sentences).`;
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error generating creative confirmation:", error);
    // Fallback message in case of an API error
    return `Your booking for a ${vehicleName} is confirmed, ${passengerName}. Get ready for a luxurious ride! We look forward to serving you.`;
  }
};
