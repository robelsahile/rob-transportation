import React from 'react';
import { APP_NAME } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-primary text-gray-300 py-6 text-center">
      <div className="container mx-auto px-4 max-w-4xl">
        <p>&copy; {new Date().getFullYear()} {APP_NAME}. All rights reserved.</p>
        <p className="text-xs mt-1">Experience the difference with premium travel.</p>
      </div>
    </footer>
  );
};

export default Footer;