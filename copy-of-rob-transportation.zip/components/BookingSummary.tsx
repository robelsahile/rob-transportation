
import React from 'react';
import { BookingData, VehicleOption } from '../types';
import Button from './Button';

interface BookingSummaryProps {
  bookingDetails: Omit<BookingData, 'id' | 'created_at'>;
  vehicle: VehicleOption;
  onConfirm: () => void;
  onEdit: () => void;
}

const InfoRow: React.FC<{ label: string; value: string | undefined }> = ({ label, value }) => (
  <div className="flex flex-col sm:flex-row justify-between py-3 border-b border-slate-200">
    <dt className="text-sm font-medium text-brand-text-light">{label}</dt>
    <dd className="text-sm text-brand-text text-left sm:text-right mt-1 sm:mt-0">{value || 'N/A'}</dd>
  </div>
);

const BookingSummary: React.FC<BookingSummaryProps> = ({ bookingDetails, vehicle, onConfirm, onEdit }) => {
  const formatDateTime = (dateTimeString: string) => {
    if (!dateTimeString) return 'N/A';
    return new Date(dateTimeString).toLocaleString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  };

  return (
    <div className="bg-brand-surface p-6 sm:p-8 rounded-lg shadow-xl animate-fade-in">
      <h2 className="text-2xl font-semibold text-brand-text mb-6 border-b pb-3 border-slate-200">Review Your Booking</h2>
      <dl>
        <InfoRow label="Pickup Location" value={bookingDetails.pickupLocation} />
        <InfoRow label="Drop-off Location" value={bookingDetails.dropoffLocation} />
        <InfoRow label="Date & Time" value={formatDateTime(bookingDetails.dateTime)} />
        <InfoRow label="Full Name" value={bookingDetails.name} />
        <InfoRow label="Phone" value={bookingDetails.phone} />
        <InfoRow label="Email" value={bookingDetails.email} />
      </dl>
      <div className="mt-6 p-4 bg-sky-50 rounded-lg border border-slate-200 flex items-center">
        <img src={vehicle.image} alt={vehicle.name} className="w-24 h-16 object-cover rounded-md" />
        <div className="ml-4">
          <h3 className="text-lg font-semibold text-brand-text">{vehicle.name}</h3>
          <p className="text-sm text-brand-text-light">{vehicle.capacity}</p>
        </div>
      </div>
      <div className="mt-8 flex flex-col sm:flex-row-reverse gap-4">
        <Button onClick={onConfirm} variant="primary" fullWidth>Confirm & Book Now</Button>
        <Button onClick={onEdit} variant="secondary" fullWidth>Edit Booking</Button>
      </div>
    </div>
  );
};

export default BookingSummary;
