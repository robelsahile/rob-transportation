
import React from 'react';
import { BookingData, VehicleOption } from '../types';
import Button from './Button';

interface ConfirmationPageProps {
  bookingDetails: Omit<BookingData, 'id' | 'created_at'>;
  vehicle: VehicleOption | null;
  message: string;
  onNewBooking: () => void;
}

const ConfirmationPage: React.FC<ConfirmationPageProps> = ({ bookingDetails, vehicle, message, onNewBooking }) => {
  return (
    <div className="bg-brand-surface p-6 sm:p-8 rounded-lg shadow-xl text-center animate-fade-in">
      <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100">
          <svg className="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" aria-hidden="true">
            <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
          </svg>
      </div>
      <h2 className="text-2xl font-bold text-brand-text mt-4">Booking Confirmed!</h2>
      <div className="mt-4 text-brand-text-light text-md prose max-w-none">
          <p>{message}</p>
      </div>

      <div className="mt-6 pt-6 border-t border-slate-200 text-left">
          <h3 className="text-lg font-semibold text-brand-text mb-4">Your Ride Summary</h3>
          <p className="text-sm text-brand-text-light"><strong>Vehicle:</strong> {vehicle?.name}</p>
          <p className="text-sm text-brand-text-light"><strong>Pickup:</strong> {bookingDetails.pickupLocation}</p>
          <p className="text-sm text-brand-text-light"><strong>Date:</strong> {new Date(bookingDetails.dateTime).toLocaleString()}</p>
      </div>
      
      <div className="mt-8">
        <Button onClick={onNewBooking} variant="primary">
          Book Another Ride
        </Button>
      </div>
    </div>
  );
};

export default ConfirmationPage;
